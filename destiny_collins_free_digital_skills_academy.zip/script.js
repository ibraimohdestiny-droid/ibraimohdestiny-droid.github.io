const courses = {
corel: {title:"CorelDRAW — Beginner lessons", lessons:[
["1. Getting to know CorelDRAW",["CorelDRAW is a vector graphics application used to create designs such as flyers, logos and banners.","A vector design can be resized while keeping its edges clear.","Explore the toolbox, property bar, page area and colour palette."],"What type of graphics is CorelDRAW mainly used for?",["Vector graphics","Audio editing","Spreadsheets"],0],
["2. Shapes and selection",["Choose the Rectangle or Ellipse tool to draw basic shapes.","Use the Pick tool to select, move and resize objects.","Hold a corner handle while resizing to keep proportions where supported."],"Which tool selects and moves objects?",["Text tool","Pick tool","Zoom tool"],1],
["3. Adding text and colour",["Choose the Text tool and click on the page to type artistic text.","Select an object, then choose a fill colour from the colour palette.","Use a clear font and strong contrast so your design is easy to read."],"Which tool is used to add words?",["Text tool","Crop tool","Ellipse tool"],0]
]},
excel:{title:"Microsoft Excel — Beginner lessons",lessons:[
["1. Workbook basics",["Excel files are called workbooks. A workbook contains one or more worksheets.","Columns are labelled with letters; rows are labelled with numbers.","A cell is where a row and column meet. For example, B3 is column B, row 3."],"What is the name of the box where a row and column meet?",["Slide","Cell","Page"],1],
["2. Entering data and simple formulas",["Select a cell and type text, a number or a date.","A formula begins with an equals sign (=).","For example, =A1+B1 adds the values in cells A1 and B1."],"Which symbol begins an Excel formula?",["#","=","@"],1],
["3. SUM and formatting",["The SUM function adds numbers. Example: =SUM(B2:B6).","Select cells and use the Home tab to format numbers, borders and text.","Use a clear heading row to make a table easier to understand."],"Which formula adds the values from B2 to B6?",["=SUM(B2:B6)","=TEXT(B2:B6)","=JOIN(B2:B6)"],0]
]},
word:{title:"Microsoft Word — Beginner lessons",lessons:[
["1. Creating a document",["Open Word and choose a blank document to start.","Type your text in the document area.","Save your work using File > Save As and choose a folder and file name."],"Which command helps you store your document?",["Save","Zoom","Replace"],0],
["2. Formatting text",["Select the words you want to format before changing them.","Use the Home tab to change font, size, colour, bold, italic and underline.","Use headings to organise longer documents."],"What should you do before formatting only one word?",["Select the word","Close Word","Print the page"],0],
["3. Page layout, lists and tables",["Use the Layout tab to adjust margins and page orientation.","Use bullets or numbering to organise lists.","Choose Insert > Table to add rows and columns."],"Which tab is commonly used to insert a table?",["Review","Insert","View"],1]
]},
ppt:{title:"Microsoft PowerPoint — Beginner lessons",lessons:[
["1. Understanding slides",["A PowerPoint presentation is made up of slides.","Use a title slide to introduce your topic.","Keep each slide focused on one main idea."],"What are the pages in a PowerPoint presentation called?",["Worksheets","Slides","Cells"],1],
["2. Add text and pictures",["Choose a slide layout that fits the information.","Use Insert > Pictures to add an image from your device.","Use short phrases and readable text sizes."],"Which tab helps you add a picture?",["Insert","Review","File"],0],
["3. Presenting your slides",["Use Slide Show to present your work full screen.","Use a consistent theme and avoid overcrowding slides.","Practise your presentation before showing it to an audience."],"Which view is used to show the presentation to an audience?",["Slide Show","Notes","Outline"],0]
]}
};
function showCourse(key){
 const c=courses[key]; const area=document.getElementById("lesson-area");
 document.getElementById("lesson-title").textContent=c.title;
 const host=document.getElementById("lesson-content"); host.innerHTML="";
 c.lessons.forEach((l,i)=>{
  const box=document.createElement("article");box.className="lesson";
  box.innerHTML=`<h3>${l[0]}</h3><ul>${l[1].map(x=>`<li>${x}</li>`).join("")}</ul><div class="quiz"><b>Quick check:</b><p>${l[2]}</p>${l[3].map((o,j)=>`<label><input type="radio" name="${key}${i}" value="${j}"> ${o}</label>`).join("")}<button onclick="checkAnswer('${key}',${i})">Check answer</button><p class="feedback" id="feedback-${key}-${i}"></p></div>`;
  host.appendChild(box);
 });
 area.hidden=false;area.scrollIntoView({behavior:"smooth"});
}
function checkAnswer(key,i){
 const l=courses[key].lessons[i], chosen=document.querySelector(`input[name="${key}${i}"]:checked`), out=document.getElementById(`feedback-${key}-${i}`);
 if(!chosen){out.textContent="Choose an answer first.";return;}
 out.textContent=Number(chosen.value)===l[4]?"Correct! Well done.":"Not quite. Read the lesson again and try once more.";
}
function closeCourse(){document.getElementById("lesson-area").hidden=true;document.getElementById("courses").scrollIntoView({behavior:"smooth"});}
document.getElementById("year").textContent=new Date().getFullYear();