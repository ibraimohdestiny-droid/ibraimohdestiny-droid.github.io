DESTINY COLLINS FREE DIGITAL SKILLS ACADEMY

Included free beginner courses:
- CorelDRAW
- Microsoft Excel
- Microsoft Word
- Microsoft PowerPoint

PUBLISH / UPDATE ON GITHUB PAGES
1. Extract this ZIP file.
2. Open your GitHub repository: ibraimohdestiny-droid.github.io
3. Upload index.html, style.css, script.js and the assets folder to the repository root.
4. Replace existing files when GitHub asks. Keep the assets folder and its destiny-profile.png file.
5. Commit changes. GitHub Pages will redeploy automatically.

The website contains beginner lessons and self-check quizzes. All lessons are free. Do not publish private contact or home-address details.
